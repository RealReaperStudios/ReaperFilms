# TODO for Reaper Studios Website

- [x] Create index.html with navbar, hero, work, about, contact, footer sections using style.css
